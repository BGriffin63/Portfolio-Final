//Fall Function
class Drop{
  constructor(x, y){
  this.x = x;
  this.y = y;
  this.del=false;
  }
  
  show(){
    fill(255, 0, 0);
    noStroke();
    ellipse(this.x, this.y, 10, 10)
  }
  move(){
    this.y = this.y - 5;
  }

  hits(f){
    return (this.x > f.x - f.w && this.x < f.x + f.w && this.y > f.y - f.w * 0.4 && this.y < f.y + f.w * 0.4)
  }

  toDel(){
this.del=true;
}

}