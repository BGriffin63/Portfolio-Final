//Ship Function
class Ship{
  constructor(){
  this.x = width / 2;
  this.y = height - 40;
this.xdir=0;
  this.speed = 10;
  }
  show(){      
    fill('red');
    noStroke();
    beginShape();
    vertex(this.x - 3, this.y - 20);
    vertex(this.x + 3, this.y - 20);
    vertex(this.x + 5, this.y + 5);
    vertex(this.x - 5, this.y + 5);
    endShape(CLOSE);
   ellipse(this.x, height - 30, 50, 10)
  }

  move(){
     if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(LEFT_ARROW)) {
      this.x += -this.speed;

    }
    
    
    if (this.x>width-20){
      this.x=width-20;
  }
    if (this.x<20){
      this.x=20;
  }
  }
  
  setDir(dir){
    this.xdir = dir;
  }
}