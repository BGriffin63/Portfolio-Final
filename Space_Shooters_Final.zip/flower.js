//HP Function
function Flower(x, y) {
  this.x = x;
  this.y = y;
  this.w = 25;
  this.heart = 100;
this.xdir=1;
  
  this.show = () => {
    fill(255,0,0);

    noStroke();
    rect(this.x, this.y, this.w * 2, this.w * 0.8);
    fill(0, 255, 0);
    rect(this.x, this.y, this.heart * this.w * 0.02, this.w * 0.8);
  }

  this.shiftDown=()=>{
  this.y+=this.w;  
  this.xdir*=-1.05;
  }

  this.dead = () => {
    return (this.heart < 0 )
  }
  
  this.move=()=>{
    this.x+=this.xdir;
  }
}