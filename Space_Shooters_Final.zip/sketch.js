var ship;
var flowers = [];
var drops = [];
var gameover = false;
var score = 0;
var Hscore = 0;
var scl=2;
var bg;
let y = 0;

function setup() {
  bg = loadImage('background.jpg');
  createCanvas(640, 400);
  rectMode(CENTER);

  ship = new Ship();

  for (let i = 0; i < 5; i++) {
    flowers[i] = new Flower(i * 80 + 80, 60);
  }
}

function draw() {
  
  if (!gameover) {
    background(bg);
    for (let i = drops.length - 1; i >= 0; i--) {
      drops[i].show();
      drops[i].move();
      if (drops[i].x < -10) {
        drops.splice(i, 1);
      }
//HP system
      for (let j = flowers.length - 1; j >= 0; j--) {
        if (drops[i].hits(flowers[j])) {
          flowers[j].heart -= 15;
          drops.splice(i, 1);
          break;
        }
      }
    }

    let ouT = false;
    for (let j = flowers.length - 1; j >= 0; j--) {
      flowers[j].show();
      flowers[j].move();

      if (flowers[j].y > height) {
        gameover = true;
      }

      if (flowers[j].x > width - flowers[j].w - 20 || flowers[j].x < flowers[j].w + 20) {
        ouT = true;
      }

      if (flowers[j].dead()) {
        flowers.push(new Flower(this.flowers[j].x, 60))
        flowers.splice(j, 1);
        score++;
      }
    }
    if (ouT) {
      for (let j = flowers.length - 1; j >= 0; j--) {
        flowers[j].shiftDown();
      }
    }
    ship.move();
    ship.show();
    drawScore();

  } else {
    if (score > Hscore) {
      Hscore = score;
    }
    //Death Screen
    background(255, 0, 0);
    textAlign(CENTER);
    fill(255);
    noStroke();
    textSize(48);
    if (score == Hscore) {
      text('High Score: ' + Hscore, width / 2, height / 2 + 50)
    } else {
      text('Your Score: ' + score, width / 2, height / 2 + 50);

      textSize(20);
      text('High Score: ' + Hscore, width / 2, height / 2 + 80);
    }
text('Thanks for playing Space Shooters!', width / 2, height - 40)
    textSize(72);
    text('GAME OVER!', width / 2, height / 2 - 20)
    textSize(12);
    text('Press spacebar to start again', width / 2, height - 15)
  }
}

function drawScore() {
  textAlign(LEFT);
  noStroke();
  textSize(16);
  if (Hscore == 0) {
    fill(255);
    text('Score: ' + score, 10, 20)

  } else if (score <= Hscore) {

    fill(255);
    text('Score: ' + score, 10, 20)
    fill(128);
    text('High Score: ' + Hscore, 10, 40)
  } else if (score > Hscore) {
    fill(255);
    text('New High Score: ' + score, 10, 20)
  }

}

function keyReleased() {
  if (key !== ' ') {
    ship.setDir(0);
  }
}

function keyPressed() {
  if (keyCode == 32) {
    var drop = new Drop(ship.x, ship.y);
    drops.push(drop);
  }
  if (gameover && keyCode == 32) {
    gameover = false;
    score = 0;
    flowers = [];
    drops = [];
    for (let i = 0; i < 5; i++) {
      flowers[i] = new Flower(i * 80 + 80, 60);
    }
  }
}